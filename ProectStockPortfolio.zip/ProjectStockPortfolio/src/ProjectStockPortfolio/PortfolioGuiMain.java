package ProjectStockPortfolio;

public class PortfolioGuiMain {
	public static void main(String[] args) {
		new PortfolioGui();
	}

}
