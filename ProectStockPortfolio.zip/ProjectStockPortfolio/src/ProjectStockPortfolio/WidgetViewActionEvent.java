package ProjectStockPortfolio;
import java.awt.event.ActionListener;

public abstract class WidgetViewActionEvent implements ActionListener {

}
