package ProjectStockPortfolio;

import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class PortfolioGui {

	private final static double INITIAL_CASH = 1000.0;
	private double cash;
	private String stockName;
	private int numberOfShares;
	private double initialStockPrice;
	
	private JTextField stockField;
	private JTextField shareField;
	private JTextField perShareField;
	private JLabel cashField;
	private JButton sellButton;
	private JButton buyButton;
	
	
	PortfolioGui() {
		WidgetView wv = new WidgetView();
		PortfolioList portfolio = new PortfolioList();
		cash = INITIAL_CASH;
		
		stockField = new JTextField("Stock");
		wv.add(stockField);
		
		shareField = new JTextField("Shares");
		wv.add(shareField);
		
		perShareField = new JTextField("perShare");
		wv.add(perShareField);
		
		cashField = new JLabel("Cash: " + cash);
		wv.add(cashField);
		
		sellButton = new JButton("Sell");
		wv.add(sellButton);
		sellButton.addActionListener(new CashBalIncrementer(cashField));
		
		buyButton = new JButton("Buy");
		wv.add(buyButton);
		buyButton.addActionListener(new CashBalDecrementer(cashField));
		
		stockName = stockField.toString();
		String shareFieldValue = shareField.getText();
		numberOfShares = Integer.parseInt(shareFieldValue);
		String perShareFieldValue = perShareField.getText();
		initialStockPrice = Double.parseDouble(perShareFieldValue);
		StockHolding newStock = new StockHolding(stockName, numberOfShares, initialStockPrice);
		portfolio.add(newStock);
		
	}

	
}

class CashBalIncrementer extends WidgetViewActionEvent {
	
	private double x = getCurrentSharePrice();
	private JLabel cashField;

	public CashBalIncrementer(JLabel labelToModify) {
		cashField = labelToModify;
	}

	
	private double getCurrentSharePrice() {
		return StockHolding.numShares * StockHolding.currentPrice;
	}
	public void actionPerformed(ActionEvent e) {
		String bval = cashField.getText();
		double newVal = x + Double.parseDouble(bval);
		cashField.setText(String.valueOf(newVal));
	}
	
}

class CashBalDecrementer extends WidgetViewActionEvent {
	
	private double y = getInitialCost();
	private JLabel cashField;

	public CashBalDecrementer(JLabel labelToModify) {
		cashField = labelToModify;
	}
	
	private double getInitialCost() {
		return StockHolding.numShares * StockHolding.initialPrice;
	}

	public void actionPerformed(ActionEvent e) {
		String bval = cashField.getText();
		double newVal = Double.parseDouble(bval) - y;
		cashField.setText(String.valueOf(newVal));
	}
}
