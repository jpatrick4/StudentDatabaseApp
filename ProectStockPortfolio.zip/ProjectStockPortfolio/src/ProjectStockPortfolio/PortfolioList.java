package ProjectStockPortfolio;
import java.util.ArrayList;

public class PortfolioList {

	public String ticker;
	
	ArrayList<StockHolding> stocks = new ArrayList<StockHolding>();
	
	PortfolioList() {
		
	}
	public void add(StockHolding stock) {
		stocks.add(stock);
	}
	public void remove(StockHolding shob3) {
		stocks.remove(shob3);
	}
	public String find(String ticker) {
		if (stocks.contains(ticker)) {
			System.out.print(stocks.toString());
			return stocks.toString();
		}
		else
			return null;
	}
	public String toString() {
		return stocks.toString() + '\n';
	}
	
}
