package ProjectStockPortfolio;

public class StockHolding {

	static String ticker;
	static int numShares;
	static double initialPrice;
	static double currentPrice;
	
	StockHolding(String ticker1, int numberShares, double initialPrice1) {
		ticker = ticker1;
		numShares = numberShares;
		initialPrice = initialPrice1;
	}
	
	public String getTicker() {
		return ticker;
	}
	public int getShares() {
		return numShares;
	}
	public double getInitialSharePrice() {
		return initialPrice;
	}
	public double getCurrentSharePrice() {
		return currentPrice;
	}
	public double getInitialCost() {
		return numShares * initialPrice;
	}
	public double getCurrentValue() {
		return numShares * currentPrice;
	}
	public double getCurrentProfit() {
		return numShares * (currentPrice - initialPrice);
	}
	@Override
	public String toString() {
		return  "<" + ticker + ">, " + "number of shares <" + numShares + ">, " + '\n' + "bought at <" + initialPrice + ">, "
				+ " current price <" + currentPrice + ">.";
	}
	public void setCurrentSharePrice(double sharePrice) {
		currentPrice = sharePrice;
	}
	
}
